/*
James Dotson
  /\_/\
=( °w° )=
  )   (  //
 (__ __)//
CODE CAT APPROVED!
*/
package com.example.cygnus68.classyinsultgenerator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity
{
    TextView insultTextView;
    Button insultButton;
    int arraySize = 50;
    String INSULT = "";
    String prePrefix= "Thou ";
    String[] prefix, primary, postfix;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefix = new String[]{"artless", "bawdy", "beslubbering", "bootless", "churlish",
            "cockered", "clouted", "craven", "currish", "dankish",
            "dissembling", "droning", "errant", "fawining", "fobbing",
            "froward", "frothy", "gleeking", "goatish", "gorebellied",
            "impertinent", "infectious", "jarring", "loggerheaded", "lumpish",
            "mammering", "mangled", "mewling", "paunchy", "pribbling",
            "puking", "puny", "qualling", "rank", "reeky",
            "roguish", "ruttish", "saucy", "spleeny", "spongy",
            "surly", "tottering", "unmuzzled", "vain", "venomed",
            "villianous", "warped", "wayward", "weedy", "yeasty"};

        primary = new String[]{"base-court", "bat-fowling", "beef-witted", "beetle-headed", "boil-brained",
            "clapper-clawed", "clay-brained", "common-kissing", "crook-pated", "dismal-dreaming",
            "dizzy-eyed", "doghearted", "dread-bolted", "earth-vexing", "elf-skinned",
            "fat-kidneyed", "fen-sucked", "flap-mouthed", "fly-bitten", "folly-fallen",
            "fool-born", "full-gorged", "guts-gripping", "half-faced", "hasty-witted",
            "hedge-born", "hell-hated", "idle-headed", "ill-breeding", "ill-nurtured",
            "knotty-pated", "milk-livered", "motley-minded", "onion-eyed", "plume-plucked",
            "pottle-deep", "pox-marked", "reeling-ripe", "rough-hewn", "rude-growing",
            "rump-fed", "shard-borne", "sheep-biting", "spur-galled", "swag-bellied",
            "tardy-gaited", "tickle-brained", "toad-spotted", "unchin-snouted", "weather-bitten"};

        postfix = new String[]{"apple-john", "baggage", "barnacle", "bladder", "boar-pig",
            "bugbear", "bum-bailey", "canker-blossom", "clack-dish", "clotpole",
            "coxcomb", "codpiece", "death-token", "dewberry", "flap-dragon",
            "flax-wench", "flirt-gill", "foot-licker", "fustilarian", "giglet",
            "gudgeon", "haggard", "harpy", "hedhe-pig", "horn-beast",
            "hugger-mugger", "joithead", "lewdster", "lout", "maggot-pie",
            "malt-worm", "mammet", "measle", "minnow", "miscreant",
            "moldwarp", "mumble-news", "nut-hoot", "pigeon-egg", "pignut",
            "puttock", "pumpion", "ratsbane", "scut", "skainsmate",
            "strumpet", "varlot", "vassal", "whey-face", "wagtail"};

        insultTextView = (TextView) findViewById(R.id.insultTextView);
        insultButton = (Button) findViewById(R.id.insultButton);
        insultButton.setOnClickListener(insultGO);
    }

    Button.OnClickListener insultGO = new Button.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            INSULT = prePrefix + "\n" + getPrefix() + "\n" + getPrimary() + "\n" + getPostfix() + "!";
            insultTextView.setText(INSULT);
        }
    };

    public int randomInsult()
    {
        Random rand = new Random();
        return rand.nextInt(arraySize);
    }

    public String getPrefix()
    {
        return prefix[randomInsult()];
    }

    public String getPrimary()
    {
        return primary[randomInsult()];
    }

    public String getPostfix()
    {
        return postfix[randomInsult()];
    }
}
